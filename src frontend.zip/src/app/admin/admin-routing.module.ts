import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from '../home/home.component';
import { MatchlistComponent } from '../matchlist/matchlist.component';
import { MenuComponent } from '../menu/menu.component';
import { ViewmatchComponent } from '../viewmatch/viewmatch.component';
import { EditmatchComponent } from '../editmatch/editmatch.component';
import { AddmatchComponent } from '../addmatch/addmatch.component';
import { EdituserComponent } from '../edituser/edituser.component';
import { BookTicketComponent } from '../book-ticket/book-ticket.component';

const routes: Routes = [
  {
    path: '',
    component: MenuComponent,
    children: [
      { path: 'home', component: HomeComponent },
      { path: '', redirectTo: '/admin/home', pathMatch: 'full' },
      { path: 'matches', component: MatchlistComponent },
      { path: 'matches/:id', component: ViewmatchComponent },
      { path:'editmatch/:id',component: EditmatchComponent},
      { path:'addmatch',component: AddmatchComponent},
      { path:'updateuser',component: EdituserComponent},
      { path:'BookTicket/:id',component: BookTicketComponent},
      
      //{ path:'view/:RegId', component:ViewRegistrationComponent}
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
