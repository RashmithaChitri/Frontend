import { Component } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { IRegistrationModel } from '../Models/Registration';
import { DataaccessService } from '../services/dataaccess.service';

@Component({
  selector: 'app-edituser',
  templateUrl: './edituser.component.html',
  styleUrls: ['./edituser.component.css']
})
export class EdituserComponent {
  constructor(private datastore:DataaccessService,private route: ActivatedRoute,public router: Router){
  }
  
    
  
  ngOnInit(): void {
    //const id = this.route.snapshot.paramMap.get('id');
    
    this.editUserDetails(5);
  }
  private user_Id:number=0;
  userdata:IRegistrationModel= {id:0, name:'',email:'',password:'',
  contactNo:'',isAdmin:false};
  editUserDetails(id:number){
    const userId = JSON.parse( localStorage.getItem('userId')||"0");
    this.user_Id = userId !== null ? userId:0;
  var data=this.datastore.GetUserDetails( userId).subscribe((data: any)=>{
    if(data != null){
      this.userdata=data;
      }
     else{
        alert('no data available');
      }
    });
  }
  updateUserDetails(){
    this.datastore.UpdateUserDetails(this.userdata).subscribe((data:any)=>{
      if(data != null){
       alert(data);
       const redirectUrl = './admin/matches';
       const navigationExtras: NavigationExtras = {
      queryParamsHandling: 'preserve',
      preserveFragment: true
    };
  
    // Redirect the user
    this.router.navigate([redirectUrl], navigationExtras);
        }
       else{
          alert('no data available');
        }
      });
  }
  
}
