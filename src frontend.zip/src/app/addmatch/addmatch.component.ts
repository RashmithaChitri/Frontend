import { Component } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { IMatchdetails } from '../Models/Matchdetails';
import { DataaccessService } from '../services/dataaccess.service';

@Component({
  selector: 'app-addmatch',
  templateUrl: './addmatch.component.html',
  styleUrls: ['./addmatch.component.css']
})
export class AddmatchComponent {
  constructor(private datastore:DataaccessService,private route: ActivatedRoute,public router: Router){
  }

  matchDetails:IMatchdetails={id:0, matchName:'', stadiumName:'', matchDate:new Date,  matchTime:'',ticketPrice:0, noOfTickets:0};
   AddMatchDetails(){
    this.datastore.AddMatchDetails(this.matchDetails).subscribe((data: any)=>{
      if(data != null){
        alert(data);
        const redirectUrl = './admin/matches';
     const navigationExtras: NavigationExtras = {
    queryParamsHandling: 'preserve',
    preserveFragment: true
  };

  // Redirect the user
  this.router.navigate([redirectUrl], navigationExtras);
      }
      else{
        alert('no data available');
      }
    })
   }
}
