import { Component } from '@angular/core';
import { DataaccessService } from '../services/dataaccess.service';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { IBookticketdetails } from '../Models/Booktickets';
import { IMatchdetails } from '../Models/Matchdetails';
@Component({
  selector: 'app-book-ticket',
  templateUrl: './book-ticket.component.html',
  styleUrls: ['./book-ticket.component.css']
})
export class BookTicketComponent {
  constructor(private dataService: DataaccessService,public router: Router,private route: ActivatedRoute) { 

   }
   ngOnInit(): void {
    const id = JSON.parse( this.route.snapshot.paramMap.get('id')||"0");
    this.match_Id=id!==''?id:0;
    this. GetMatchDetails();
  }
   
   user_Id:number=0;
   match_Id:number=0;
   totalPrice:number=0;
  Bookticket:IBookticketdetails= {id:0, RegistrationId:0,MatchdetailId :0, NoOfSeats:0,price:0};
  matchDetails: IMatchdetails ={id:0,matchName:'',stadiumName:'',matchDate:new Date,matchTime:'',ticketPrice:0,noOfTickets:0};
  
 
  BookTicketDetails(){
    
    const userId = JSON.parse( localStorage.getItem('userId')||"0");
    this.user_Id=userId!==null?userId:0;
    console.log(this.Bookticket);
    this.Bookticket.RegistrationId=this.user_Id;
    
    this.Bookticket.MatchdetailId=this.match_Id;
    this.Bookticket.price=this.totalPrice;
   
   this.dataService.BookTicketDetails(this.Bookticket).subscribe((data: any)=>{
    
     if(data != null){
      alert(data);
       const redirectUrl = './admin/matches';
       const navigationExtras: NavigationExtras = {
         queryParamsHandling: 'preserve',
         preserveFragment: true
       };
     
       // Redirect the user
       this.router.navigate([redirectUrl], navigationExtras);
     }
      else{
         alert('Invalid user');
       }
     });
  }
  GetMatchDetails(){
    var data=this.dataService.GetViewmatchDetails(this.match_Id).subscribe((data: any)=>{
      if(data != null){
        this.matchDetails=data;
        }
       else{
          alert('no data available');
        }
      });

  }
  GetTotalprice(){
    this.totalPrice=this.matchDetails.ticketPrice*this.Bookticket.NoOfSeats
  }


}
