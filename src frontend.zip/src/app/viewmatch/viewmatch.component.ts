import { identifierName } from '@angular/compiler';
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { IMatchdetails } from '../Models/Matchdetails';
import { DataaccessService } from '../services/dataaccess.service';

@Component({
  selector: 'app-viewmatch',
  templateUrl: './viewmatch.component.html',
  styleUrls: ['./viewmatch.component.css']
})
export class ViewmatchComponent {
  constructor(private datastore:DataaccessService,private route: ActivatedRoute){
  }
  
  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    this.GetViewmatchDetails(id);
  }
  
  matchDetails: IMatchdetails ={id:0,matchName:'',stadiumName:'',matchDate:new Date,matchTime:'',ticketPrice:0,noOfTickets:0};

  GetViewmatchDetails(id:any){
  var data=this.datastore.GetViewmatchDetails(id).subscribe((data: any)=>{
    if(data != null){
      this.matchDetails=data;
      }
     else{
        alert('no data available');
      }
    });
 }

}
