import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewmatchComponent } from './viewmatch.component';

describe('ViewmatchComponent', () => {
  let component: ViewmatchComponent;
  let fixture: ComponentFixture<ViewmatchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewmatchComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewmatchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
