export interface IBookticketdetails {
  
    id: number;
    RegistrationId:number;
    MatchdetailId :number;
    NoOfSeats: number;
    price:number;
  
}