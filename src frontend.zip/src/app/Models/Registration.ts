
export interface IRegistrationModel{
    id:number;
    name:string;
    email:string;
    password:string;
    contactNo:string;
    isAdmin:boolean;
}
