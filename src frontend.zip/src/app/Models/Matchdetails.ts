export interface IMatchdetails {
  
    id:number;
    matchName:string;
    stadiumName:string;
    matchDate:Date;
    matchTime:string;
    ticketPrice:number;
    noOfTickets:number;
  }
  