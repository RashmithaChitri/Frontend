import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, retry, throwError } from 'rxjs';
import { IRegistrationModel } from '../Models/Registration';
import { IMatchdetails } from '../Models/Matchdetails';
import { IBookticketdetails } from '../Models/Booktickets';


@Injectable({
  providedIn: 'root'
})
export class DataaccessService {

  private REST_API_SERVER = "http://localhost:45970/api/";
  

  constructor(private httpClient: HttpClient) { }

  handleError(error:any) {
    let errorMessage = '';
    if(error.status == 404){
      errorMessage='Invalid user'
    }
          
    if (error.error instanceof ErrorEvent) {
      // client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    //console.log(errorMessage);
    return throwError(() => {
        return errorMessage;
    });
  }

  public Login(emailid:string,password:string){
    return this.httpClient.get(this.REST_API_SERVER+"Registrations/Login?emailid="+emailid+"&password="+password).pipe(catchError(this.handleError));
  }
  public GetMatchDetails(){
    return this.httpClient.get(this.REST_API_SERVER+"MatchDetails").pipe(catchError(this.handleError));
  }
  public  Registration(regi: IRegistrationModel){
    return this.httpClient.post(this.REST_API_SERVER+"Registrations",regi,{responseType: 'text'}).pipe(catchError(this.handleError)); 
    }
  public GetViewmatchDetails(id:number){
      return this.httpClient.get(this.REST_API_SERVER+"MatchDetails/"+id).pipe(catchError(this.handleError));
    }
    
  public UpdateMatchDetails(matchData:IMatchdetails){
      return this.httpClient.put(this.REST_API_SERVER+"MatchDetails/"+matchData.id,matchData,{responseType: 'text'}).pipe(catchError(this.handleError));
    }
    public DeleteMatchDetails(id:number){
      return this.httpClient.delete(this.REST_API_SERVER+"MatchDetails/"+id,{responseType: 'text'}).pipe(catchError(this.handleError));
    }
    public AddMatchDetails(matchData:IMatchdetails){
      return this.httpClient.post(this.REST_API_SERVER+"MatchDetails",matchData,{responseType:'text'}).pipe(catchError(this.handleError));
    }
    public GetUserDetails(id:number){
      return this.httpClient.get(this.REST_API_SERVER+"Registrations/"+id).pipe(catchError(this.handleError));
    }
    public UpdateUserDetails(userData:IRegistrationModel){
        return this.httpClient.put(this.REST_API_SERVER+"Registrations/"+userData.id,userData,{responseType: 'text'}).pipe(catchError(this.handleError));
    }
    public BookTicketDetails(ticket: IBookticketdetails){
      return this.httpClient.post(this.REST_API_SERVER+"MatchticketBookings",ticket,{responseType: 'text'}).pipe(catchError(this.handleError));
    }
    
}
