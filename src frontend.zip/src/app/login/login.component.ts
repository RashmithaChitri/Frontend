import { Component} from '@angular/core';
import { DataaccessService } from '../services/dataaccess.service';
import { NavigationExtras, Router } from '@angular/router';
import { IRegistrationModel } from '../Models/Registration';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  constructor(private dataService: DataaccessService,public router: Router) { }
emailid:string='';
password:string='';
loginUser(){
  this.dataService.Login(this.emailid,this.password).subscribe((data: any)=>{
    
if(data != null){
  localStorage.setItem('userId',data.id);
  localStorage.setItem('isAdmin',data.isAdmin);

  const redirectUrl = './admin/home';
  //console.log(data);
  // Set our navigation extras object
  // that passes on our global query params and fragment
  const navigationExtras: NavigationExtras = {
    queryParamsHandling: 'preserve',
    preserveFragment: true
  };

  // Redirect the user
  this.router.navigate([redirectUrl], navigationExtras);
}
 else{
    alert('Invalid user');
  }
    
  })  
}


}

