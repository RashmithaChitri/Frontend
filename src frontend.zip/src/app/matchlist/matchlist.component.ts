import { Component } from '@angular/core';
import { IMatchdetails } from '../Models/Matchdetails';
import { DataaccessService } from '../services/dataaccess.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-matchlist',
  templateUrl: './matchlist.component.html',
  styleUrls: ['./matchlist.component.css']
})
export class MatchlistComponent {
  matchlist:IMatchdetails[]=[];
  
  is_Admin:boolean=false;
  user_Id:number=0;
    constructor(private datastore:DataaccessService,public router: Router){
    }
    
    ngOnInit(): void {
      this.getmatchlistData();
    }
    
   getmatchlistData(){
    
    const userId = JSON.parse( localStorage.getItem('userId')||"0");
    const isAdmin= JSON.parse( localStorage.getItem('isAdmin')||"false");
    this.is_Admin=isAdmin!==null?isAdmin:false;
    
    this.user_Id=userId!==null?userId:0;
    
    this.datastore. GetMatchDetails().subscribe((data: any)=>{
      if(data != null){
        this.matchlist=data;
        }
       else{
          alert('no data available');
        }
      });
   }
   DeleteMatchDetails(id:number){
    this.datastore. DeleteMatchDetails(id).subscribe((data: any)=>{
      if(data != null){
       alert(data);
       this.getmatchlistData();
        }
       else{
          alert('no data available');
        }
      });
   }
   

}
