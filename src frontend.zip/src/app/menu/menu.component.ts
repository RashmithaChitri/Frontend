import { Component } from '@angular/core';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent {
  is_Admin:boolean=false;
  ngOnInit(): void {
    const isAdmin= JSON.parse( localStorage.getItem('isAdmin')||"false");
    this.is_Admin=isAdmin!==null?isAdmin:false;

    
  }
  
  
    
}
