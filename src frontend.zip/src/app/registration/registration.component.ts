import { Component } from '@angular/core';
import { DataaccessService } from '../services/dataaccess.service';
import { NavigationExtras, Router } from '@angular/router';
import { IRegistrationModel } from '../Models/Registration';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent {
  constructor(private dataService: DataaccessService,public router: Router) { }
  registration:IRegistrationModel= {id:0, name:'',email:'',password:'',
  contactNo:'',isAdmin:false};
 
  Registration(){
   
   this.dataService.Registration(this.registration).subscribe((data: any)=>{
     if(data != null){
       const redirectUrl = '/login';
       const navigationExtras: NavigationExtras = {
         queryParamsHandling: 'preserve',
         preserveFragment: true
       };
     
       // Redirect the user
       this.router.navigate([redirectUrl], navigationExtras);
     }
      else{
         alert('Invalid user');
       }
     });
  }

}
