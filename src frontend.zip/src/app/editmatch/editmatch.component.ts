import { Component } from '@angular/core';
import { DataaccessService } from '../services/dataaccess.service';
import { IMatchdetails } from '../Models/Matchdetails';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { identifierName } from '@angular/compiler';

@Component({
  selector: 'app-editmatch',
  templateUrl: './editmatch.component.html',
  styleUrls: ['./editmatch.component.css']
})
export class EditmatchComponent {
  constructor(private datastore:DataaccessService,private route: ActivatedRoute,public router: Router){
}

ngOnInit(): void {
  const id = this.route.snapshot.paramMap.get('id');
  this.editmatchDetails(id);
}

matchDetails: IMatchdetails ={id:0,matchName:'',stadiumName:'',matchDate:new Date,matchTime:'',ticketPrice:0,noOfTickets:0};

editmatchDetails(id:any){
var data=this.datastore.GetViewmatchDetails(id).subscribe((data: any)=>{
  if(data != null){
    this.matchDetails=data;
    }
   else{
      alert('no data available');
    }
  });
}
updateMatchDetails(){
  var daat=this.datastore.UpdateMatchDetails(this.matchDetails).subscribe((data:any)=>{
    if(data != null){
     alert(data);
     const redirectUrl = './admin/matches';
     const navigationExtras: NavigationExtras = {
    queryParamsHandling: 'preserve',
    preserveFragment: true
  };

  // Redirect the user
  this.router.navigate([redirectUrl], navigationExtras);
      }
     else{
        alert('no data available');
      }
    });
}

}
