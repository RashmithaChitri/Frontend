import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatMenuModule } from '@angular/material/menu';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { RouterModule, Routes }   from '@angular/router';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatTooltipModule } from '@angular/material/tooltip';

import { AppComponent } from './app.component';
import { MenuComponent } from './menu/menu.component';
import { HomeComponent } from './home/home.component';
import { AppRoutingModule} from './app-routing.module';
import { LoginComponent } from './login/login.component';
import {HttpClientModule} from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';

import { MatCardModule} from '@angular/material/card';
import { MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { MatchlistComponent } from './matchlist/matchlist.component';
import { RegistrationComponent } from './registration/registration.component';
import { ViewmatchComponent } from './viewmatch/viewmatch.component';
import { EditmatchComponent } from './editmatch/editmatch.component';
import { AddmatchComponent } from './addmatch/addmatch.component';
import { EdituserComponent } from './edituser/edituser.component';
import { BookTicketComponent } from './book-ticket/book-ticket.component';


@NgModule({
  declarations: [ 
    AppComponent,
    MenuComponent,
    LoginComponent,
    MatchlistComponent,
    RegistrationComponent,
    ViewmatchComponent,
    EditmatchComponent,
    AddmatchComponent,
    EdituserComponent,
    BookTicketComponent,
    
    
  ],
  imports: [

    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    MatButtonModule,
    MatSidenavModule,
    MatMenuModule,
    MatToolbarModule,
    MatIconModule,
    MatListModule,
    AppRoutingModule,
    MatExpansionModule,
    MatTooltipModule,
    HttpClientModule,
    ReactiveFormsModule,
    MatCardModule,
    MatProgressSpinnerModule
  ],
  providers: [
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }